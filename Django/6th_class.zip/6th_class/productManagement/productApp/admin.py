from django.contrib import admin
from productApp.models import *

# Register your models here.
admin.site.register(productModel)
admin.site.register(customerModel)
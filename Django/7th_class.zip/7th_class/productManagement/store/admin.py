from django.contrib import admin
from store.models import *

# Register your models here.

admin.site.register(booksModel)
admin.site.register(userModel)
admin.site.register(studentModel)

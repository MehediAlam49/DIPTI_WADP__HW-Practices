from django.contrib import admin
from library.models import *

# Register your models here.
admin.site.register(studentModel)
admin.site.register(bookModel)
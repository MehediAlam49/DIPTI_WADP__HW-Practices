from django.contrib import admin
from inventory.models import *

# Register your models here.
admin.site.register(courseModel)
admin.site.register(studentModel)
admin.site.register(teacherModel)